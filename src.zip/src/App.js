import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/AdminDashboard';
import CandidateDashboard from './pages/CandidateDashboard';
import ExamPage from './pages/ExamPage';
import ResultPage from './pages/ResultPage';
import ManageExams from './pages/ManageExams';
import ManageQuestions from './pages/ManageQuestions';
import Analytics from './pages/Analytics';
import ProfilePage from './pages/ProfilePage';
import Notifications from './pages/Notifications';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/exams" element={<ManageExams />} />
        <Route path="/admin/questions/:examId" element={<ManageQuestions />} />
        <Route path="/admin/analytics" element={<Analytics />} />
        <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
        <Route path="/exam/:examId" element={<ExamPage />} />
        <Route path="/result/:attemptId" element={<ResultPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
