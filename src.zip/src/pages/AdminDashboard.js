import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './AdminDashboard.css';

function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await API.get('admin/dashboard/');
      setStats(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div className="admin-dashboard">
      <nav className="navbar">
        <h2>Admin Dashboard</h2>
        <div>
          <button onClick={() => navigate('/admin/exams')}>Manage Exams</button>
          <button onClick={() => navigate('/admin/analytics')}>Analytics</button>
          <button onClick={handleLogout}>Logout</button>
        </div>
      </nav>

      <div className="stats-container">
        <div className="stat-card">
          <h3>{stats?.total_candidates || 0}</h3>
          <p>Total Candidates</p>
        </div>
        <div className="stat-card">
          <h3>{stats?.total_exams || 0}</h3>
          <p>Total Exams</p>
        </div>
        <div className="stat-card">
          <h3>{stats?.active_exams || 0}</h3>
          <p>Active Exams</p>
        </div>
        <div className="stat-card">
          <h3>{stats?.pass_percentage || 0}%</h3>
          <p>Pass Percentage</p>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
