import React from 'react';
import { useNavigate } from 'react-router-dom';
import './LandingPage.css';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="landing-page">
      <div className="hero">
        <h1>Exam Management System</h1>
        <p>Manage and take exams online with ease</p>
        <div className="buttons">
          <button onClick={() => navigate('/login')}>Login</button>
          <button onClick={() => navigate('/register')}>Register</button>
        </div>
      </div>

      <div className="features">
        <div className="feature">
          <h3>📝 Easy Exam Creation</h3>
          <p>Create and manage exams with multiple question types</p>
        </div>
        <div className="feature">
          <h3>📊 Real-time Analytics</h3>
          <p>Track performance and generate detailed reports</p>
        </div>
        <div className="feature">
          <h3>🔒 Secure & Reliable</h3>
          <p>Your data is safe with our secure platform</p>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
