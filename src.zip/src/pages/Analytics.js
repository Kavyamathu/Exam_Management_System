import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './Analytics.css';

function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [exams, setExams] = useState([]);
  const [selectedExam, setSelectedExam] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchExams();
    fetchAnalytics();
  }, []);

  const fetchExams = async () => {
    try {
      const response = await API.get('exams/');
      setExams(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAnalytics = async (examId = '') => {
    try {
      const url = examId ? `admin/analytics/?exam_id=${examId}` : 'admin/analytics/';
      const response = await API.get(url);
      setAnalytics(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleExamChange = (e) => {
    const examId = e.target.value;
    setSelectedExam(examId);
    fetchAnalytics(examId);
  };

  return (
    <div className="analytics-page">
      <nav className="navbar">
        <h2>Performance Analytics</h2>
        <div>
          <button onClick={() => navigate('/admin/dashboard')}>Dashboard</button>
        </div>
      </nav>

      <div className="analytics-content">
        <div className="filter-section">
          <label>Filter by Exam:</label>
          <select value={selectedExam} onChange={handleExamChange}>
            <option value="">All Exams</option>
            {exams.map(exam => (
              <option key={exam.id} value={exam.id}>{exam.title}</option>
            ))}
          </select>
        </div>

        {analytics && (
          <>
            <div className="stats-grid">
              <div className="stat-card">
                <h3>{analytics.average_score.toFixed(2)}</h3>
                <p>Average Score</p>
              </div>
              <div className="stat-card">
                <h3>{analytics.pass_fail_ratio.passed}</h3>
                <p>Passed</p>
              </div>
              <div className="stat-card">
                <h3>{analytics.pass_fail_ratio.failed}</h3>
                <p>Failed</p>
              </div>
              <div className="stat-card">
                <h3>{analytics.pass_fail_ratio.total}</h3>
                <p>Total Attempts</p>
              </div>
            </div>

            <div className="chart-section">
              <h3>Pass/Fail Ratio</h3>
              <div className="chart">
                <div 
                  className="bar passed" 
                  style={{
                    width: `${(analytics.pass_fail_ratio.passed / analytics.pass_fail_ratio.total * 100) || 0}%`
                  }}
                >
                  {analytics.pass_fail_ratio.passed}
                </div>
                <div 
                  className="bar failed" 
                  style={{
                    width: `${(analytics.pass_fail_ratio.failed / analytics.pass_fail_ratio.total * 100) || 0}%`
                  }}
                >
                  {analytics.pass_fail_ratio.failed}
                </div>
              </div>
            </div>

            <div className="top-scorers">
              <h3>Top Scorers</h3>
              <table>
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Exam</th>
                    <th>Score</th>
                    <th>Percentage</th>
                  </tr>
                </thead>
                <tbody>
                  {analytics.top_scorers.map((scorer, idx) => (
                    <tr key={idx}>
                      <td>{idx + 1}</td>
                      <td>{scorer.candidate__username}</td>
                      <td>{scorer.candidate__email}</td>
                      <td>{scorer.exam__title}</td>
                      <td>{scorer.score}</td>
                      <td>{scorer.percentage}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Analytics;
