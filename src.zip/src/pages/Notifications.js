import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './Notifications.css';

function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await API.get('notifications/');
      setNotifications(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const markAsRead = async (id) => {
    try {
      await API.post(`notifications/${id}/mark_read/`);
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await API.post('notifications/mark_all_read/');
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const getIcon = (type) => {
    switch(type) {
      case 'EXAM_ALERT': return '📝';
      case 'RESULT_PUBLISHED': return '📊';
      case 'UPCOMING_TEST': return '⏰';
      default: return '🔔';
    }
  };

  return (
    <div className="notifications-page">
      <nav className="navbar">
        <h2>🔔 Notifications</h2>
        <div>
          {notifications.some(n => !n.is_read) && (
            <button onClick={markAllAsRead} className="mark-all-btn">
              Mark All as Read
            </button>
          )}
          <button onClick={() => navigate('/candidate/dashboard')}>Dashboard</button>
        </div>
      </nav>

      <div className="notifications-content">
        {!notifications ? (
          <div className="loading">Loading notifications...</div>
        ) : notifications.length === 0 ? (
          <div className="no-notifications">
            <div className="empty-icon">🔔</div>
            <h3>No Notifications</h3>
            <p>You're all caught up! Check back later for updates.</p>
          </div>
        ) : (
          <>
            <div className="notifications-header">
              <h3>All Notifications ({notifications.length})</h3>
              <div className="filter-tabs">
                <span className="tab active">All</span>
                <span className="tab">Unread ({notifications.filter(n => !n.is_read).length})</span>
              </div>
            </div>
            <div className="notifications-list">
              {notifications.map(notification => (
                <div 
                  key={notification.id} 
                  className={`notification-card ${notification.is_read ? 'read' : 'unread'}`}
                >
                  <div className="notification-icon">
                    {getIcon(notification.notification_type)}
                  </div>
                  <div className="notification-content">
                    <div className="notification-header">
                      <h4>{notification.title}</h4>
                      {!notification.is_read && <span className="unread-badge">New</span>}
                    </div>
                    <p className="notification-message">{notification.message}</p>
                    {notification.exam_title && (
                      <div className="exam-info">
                        <span className="exam-icon">📚</span>
                        <span className="exam-name">{notification.exam_title}</span>
                      </div>
                    )}
                    <div className="notification-footer">
                      <span className="time-ago">
                        {formatTimeAgo(notification.created_at)}
                      </span>
                      {!notification.is_read && (
                        <button 
                          onClick={() => markAsRead(notification.id)}
                          className="mark-read-btn"
                        >
                          Mark as Read
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// Helper function to format time
function formatTimeAgo(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);
  
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)} days ago`;
  return date.toLocaleDateString();
}

export default Notifications;
