import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './CandidateDashboard.css';

function CandidateDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await API.get('candidate/dashboard/');
      setDashboard(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const startExam = (examId) => {
    navigate(`/exam/${examId}`);
  };

  return (
    <div className="candidate-dashboard">
      <nav className="navbar">
        <h2>Candidate Dashboard</h2>
        <div>
          <button onClick={() => navigate('/profile')}>Profile</button>
          <button onClick={() => navigate('/notifications')}>Notifications</button>
          <button onClick={handleLogout}>Logout</button>
        </div>
      </nav>

      <div className="dashboard-content">
        <section className="section">
          <h3>Upcoming Exams</h3>
          {!dashboard ? (
            <p>Loading...</p>
          ) : dashboard?.upcoming_exams?.length === 0 ? (
            <p className="no-data">No upcoming exams available</p>
          ) : (
            <div className="exam-list">
              {dashboard?.upcoming_exams?.map(exam => (
                <div key={exam.id} className="exam-card">
                  <h4>{exam.title}</h4>
                  <p><strong>Department:</strong> {exam.department}</p>
                  <p><strong>Type:</strong> {exam.exam_type}</p>
                  <p><strong>Date:</strong> {new Date(exam.exam_date).toLocaleString()}</p>
                  <p><strong>Duration:</strong> {exam.duration} minutes</p>
                  <p><strong>Total Questions:</strong> {exam.total_questions}</p>
                  <p><strong>Total Marks:</strong> {exam.total_marks}</p>
                  <p><strong>Pass Marks:</strong> {exam.pass_marks}</p>
                  <button onClick={() => startExam(exam.id)} className="start-btn">Start Exam</button>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="section">
          <h3>Completed Exams</h3>
          {!dashboard ? (
            <p>Loading...</p>
          ) : dashboard?.completed_exams?.length === 0 ? (
            <p className="no-data">No completed exams yet. Start an exam to see your results here!</p>
          ) : (
            <>
              <div className="completion-message">
                <p className="success-msg">🎉 Your exam completed successfully! Results below:</p>
              </div>
              <div className="exam-list">
                {dashboard?.completed_exams?.map(attempt => (
                  <div key={attempt.id} className="exam-card completed">
                    <div className="completion-badge">✓ COMPLETED</div>
                    <h4>{attempt.exam_title}</h4>
                    <p><strong>Score:</strong> {attempt.score} / {attempt.exam?.total_marks || 'N/A'}</p>
                    <p><strong>Percentage:</strong> {attempt.percentage?.toFixed(2)}%</p>
                    <p><strong>Completed On:</strong> {new Date(attempt.end_time).toLocaleString()}</p>
                    <p className={attempt.is_passed ? 'status passed' : 'status failed'}>
                      {attempt.is_passed ? '✓ PASSED - Congratulations!' : '✗ FAILED - Try Again!'}
                    </p>
                    <button onClick={() => navigate(`/result/${attempt.id}`)} className="view-btn">
                      View Detailed Result
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
        </section>

        <section className="section">
          <h3>Recent Notifications</h3>
          {!dashboard ? (
            <p>Loading...</p>
          ) : dashboard?.notifications?.length === 0 ? (
            <p className="no-data">No new notifications</p>
          ) : (
            <div className="notifications-preview">
              {dashboard?.notifications?.map(notif => (
                <div key={notif.id} className="notif-item">
                  <span className="notif-icon">
                    {notif.notification_type === 'EXAM_ALERT' ? '📝' : 
                     notif.notification_type === 'RESULT_PUBLISHED' ? '📊' : '⏰'}
                  </span>
                  <div className="notif-content">
                    <strong>{notif.title}</strong>
                    <p>{notif.message}</p>
                  </div>
                </div>
              ))}
              <button onClick={() => navigate('/notifications')} className="view-all-btn">
                View All Notifications
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default CandidateDashboard;
