import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './ProfilePage.css';

function ProfilePage() {
  const [profile, setProfile] = useState(null);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const [passwordData, setPasswordData] = useState({
    old_password: '',
    new_password: ''
  });
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await API.get('profile/');
      setProfile(response.data);
      setFormData(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const response = await API.put('profile/', formData);
      setProfile(response.data);
      setEditing(false);
      alert('Profile updated successfully!');
    } catch (err) {
      alert('Failed to update profile');
    }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    try {
      await API.post('profile/change-password/', passwordData);
      setShowPasswordForm(false);
      setPasswordData({ old_password: '', new_password: '' });
      alert('Password changed successfully!');
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to change password');
    }
  };

  if (!profile) return <div className="loading">Loading...</div>;

  return (
    <div className="profile-page">
      <nav className="navbar">
        <h2>My Profile</h2>
        <div>
          <button onClick={() => navigate('/candidate/dashboard')}>Dashboard</button>
        </div>
      </nav>

      <div className="profile-content">
        <div className="profile-card">
          <div className="profile-header">
            <div className="avatar">
              {profile.first_name?.[0]}{profile.last_name?.[0]}
            </div>
            <h3>{profile.first_name} {profile.last_name}</h3>
            <p>{profile.email}</p>
          </div>

          {!editing ? (
            <div className="profile-info">
              <div className="info-row">
                <span className="label">Username:</span>
                <span className="value">{profile.username}</span>
              </div>
              <div className="info-row">
                <span className="label">Email:</span>
                <span className="value">{profile.email}</span>
              </div>
              <div className="info-row">
                <span className="label">Age:</span>
                <span className="value">{profile.age || 'Not set'}</span>
              </div>
              <div className="info-row">
                <span className="label">Gender:</span>
                <span className="value">
                  {profile.gender === 'M' ? 'Male' : profile.gender === 'F' ? 'Female' : 'Other'}
                </span>
              </div>
              <div className="info-row">
                <span className="label">Phone:</span>
                <span className="value">{profile.phone || 'Not set'}</span>
              </div>
              <div className="info-row">
                <span className="label">Department:</span>
                <span className="value">{profile.department || 'Not set'}</span>
              </div>
              <div className="info-row">
                <span className="label">Organization:</span>
                <span className="value">{profile.organization || 'Not set'}</span>
              </div>
              <button onClick={() => setEditing(true)} className="edit-btn">
                Edit Profile
              </button>
              <button onClick={() => setShowPasswordForm(!showPasswordForm)} className="password-btn">
                Change Password
              </button>
            </div>
          ) : (
            <form onSubmit={handleUpdate} className="edit-form">
              <input
                placeholder="First Name"
                value={formData.first_name}
                onChange={(e) => setFormData({...formData, first_name: e.target.value})}
              />
              <input
                placeholder="Last Name"
                value={formData.last_name}
                onChange={(e) => setFormData({...formData, last_name: e.target.value})}
              />
              <input
                type="number"
                placeholder="Age"
                value={formData.age || ''}
                onChange={(e) => setFormData({...formData, age: e.target.value})}
              />
              <select
                value={formData.gender}
                onChange={(e) => setFormData({...formData, gender: e.target.value})}
              >
                <option value="M">Male</option>
                <option value="F">Female</option>
                <option value="O">Other</option>
              </select>
              <input
                placeholder="Phone"
                value={formData.phone || ''}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
              />
              <input
                placeholder="Department"
                value={formData.department || ''}
                onChange={(e) => setFormData({...formData, department: e.target.value})}
              />
              <input
                placeholder="Organization"
                value={formData.organization || ''}
                onChange={(e) => setFormData({...formData, organization: e.target.value})}
              />
              <div className="form-actions">
                <button type="submit">Save Changes</button>
                <button type="button" onClick={() => setEditing(false)}>Cancel</button>
              </div>
            </form>
          )}

          {showPasswordForm && (
            <form onSubmit={handlePasswordChange} className="password-form">
              <h4>Change Password</h4>
              <input
                type="password"
                placeholder="Old Password"
                value={passwordData.old_password}
                onChange={(e) => setPasswordData({...passwordData, old_password: e.target.value})}
                required
              />
              <input
                type="password"
                placeholder="New Password"
                value={passwordData.new_password}
                onChange={(e) => setPasswordData({...passwordData, new_password: e.target.value})}
                required
              />
              <button type="submit">Change Password</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default ProfilePage;
