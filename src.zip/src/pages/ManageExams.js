import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './ManageExams.css';

function ManageExams() {
  const [exams, setExams] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    exam_type: 'MCQ',
    department: '',
    total_questions: '',
    duration: '',
    total_marks: '',
    pass_marks: '',
    exam_date: '',
    is_active: true
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      const response = await API.get('exams/');
      setExams(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('exams/', formData);
      setShowForm(false);
      fetchExams();
      alert('Exam created successfully!');
    } catch (err) {
      alert('Failed to create exam');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this exam?')) {
      try {
        await API.delete(`exams/${id}/`);
        fetchExams();
      } catch (err) {
        alert('Failed to delete exam');
      }
    }
  };

  return (
    <div className="manage-exams">
      <nav className="navbar">
        <h2>Manage Exams</h2>
        <div>
          <button onClick={() => navigate('/admin/dashboard')}>Dashboard</button>
          <button onClick={() => setShowForm(!showForm)}>
            {showForm ? 'Cancel' : 'Create Exam'}
          </button>
        </div>
      </nav>

      {showForm && (
        <div className="exam-form">
          <h3>Create New Exam</h3>
          <form onSubmit={handleSubmit}>
            <input
              placeholder="Exam Title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              required
            />
            <select
              value={formData.exam_type}
              onChange={(e) => setFormData({...formData, exam_type: e.target.value})}
            >
              <option value="MCQ">Multiple Choice</option>
              <option value="DESCRIPTIVE">Descriptive</option>
              <option value="MIXED">Mixed</option>
            </select>
            <input
              placeholder="Department"
              value={formData.department}
              onChange={(e) => setFormData({...formData, department: e.target.value})}
              required
            />
            <input
              type="number"
              placeholder="Total Questions"
              value={formData.total_questions}
              onChange={(e) => setFormData({...formData, total_questions: e.target.value})}
              required
            />
            <input
              type="number"
              placeholder="Duration (minutes)"
              value={formData.duration}
              onChange={(e) => setFormData({...formData, duration: e.target.value})}
              required
            />
            <input
              type="number"
              placeholder="Total Marks"
              value={formData.total_marks}
              onChange={(e) => setFormData({...formData, total_marks: e.target.value})}
              required
            />
            <input
              type="number"
              placeholder="Pass Marks"
              value={formData.pass_marks}
              onChange={(e) => setFormData({...formData, pass_marks: e.target.value})}
              required
            />
            <input
              type="datetime-local"
              value={formData.exam_date}
              onChange={(e) => setFormData({...formData, exam_date: e.target.value})}
              required
            />
            <button type="submit">Create Exam</button>
          </form>
        </div>
      )}

      <div className="exams-list">
        {exams.map(exam => (
          <div key={exam.id} className="exam-card">
            <h3>{exam.title}</h3>
            <p>Department: {exam.department}</p>
            <p>Type: {exam.exam_type}</p>
            <p>Duration: {exam.duration} minutes</p>
            <p>Total Marks: {exam.total_marks}</p>
            <p>Date: {new Date(exam.exam_date).toLocaleString()}</p>
            <div className="actions">
              <button onClick={() => navigate(`/admin/questions/${exam.id}`)}>
                Manage Questions
              </button>
              <button onClick={() => handleDelete(exam.id)} className="delete-btn">
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ManageExams;
