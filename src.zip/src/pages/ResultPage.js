import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './ResultPage.css';

function ResultPage() {
  const { attemptId } = useParams();
  const navigate = useNavigate();
  const [result, setResult] = useState(null);

  useEffect(() => {
    fetchResult();
  }, []);

  const fetchResult = async () => {
    try {
      console.log('Fetching result for attempt:', attemptId);
      const response = await API.get(`attempt/${attemptId}/result/`);
      console.log('Result fetched successfully:', response.data);
      setResult(response.data);
    } catch (err) {
      console.error('Error fetching result:', err);
      alert('Failed to load result. Please check if you are logged in.');
      navigate('/candidate/dashboard');
    }
  };

  if (!result) return <div className="loading">Loading result...</div>;

  const { attempt, correct_answers, wrong_answers, total_questions, answers } = result;

  return (
    <div className="result-page">
      <div className="result-header">
        <h2>Exam Result - {attempt.exam_title}</h2>
      </div>

      <div className="result-content">
        <div className="result-summary">
          <div className={`status-badge ${attempt.is_passed ? 'passed' : 'failed'}`}>
            {attempt.is_passed ? '✓ CONGRATULATIONS! YOU PASSED' : '✗ SORRY, YOU FAILED'}
          </div>
          
          <div className="score-display">
            <div className="score-circle">
              <div className="score-value">{attempt.percentage?.toFixed(1)}%</div>
              <div className="score-label">Your Score</div>
            </div>
            <div className="score-details">
              <h3>{attempt.score} / {attempt.exam?.total_marks || 'N/A'}</h3>
              <p>Total Marks</p>
            </div>
          </div>

          <div className="stats-grid">
            <div className="stat-box correct">
              <div className="stat-number">{correct_answers}</div>
              <div className="stat-label">Correct Answers</div>
            </div>
            <div className="stat-box wrong">
              <div className="stat-number">{wrong_answers}</div>
              <div className="stat-label">Wrong Answers</div>
            </div>
            <div className="stat-box total">
              <div className="stat-number">{total_questions}</div>
              <div className="stat-label">Total Questions</div>
            </div>
          </div>

          <div className="exam-info">
            <p><strong>Exam Started:</strong> {new Date(attempt.start_time).toLocaleString()}</p>
            <p><strong>Exam Completed:</strong> {new Date(attempt.end_time).toLocaleString()}</p>
            <p><strong>Pass Marks Required:</strong> {attempt.exam?.pass_marks || 'N/A'}</p>
          </div>
        </div>

        <div className="answers-section">
          <h3>📝 Detailed Answer Review</h3>
          {answers && answers.length > 0 ? (
            answers.map((answer, idx) => (
              <div key={answer.id} className={`answer-card ${answer.is_correct ? 'correct' : 'wrong'}`}>
                <div className="answer-header">
                  <span className="question-number">Question {idx + 1}</span>
                  <span className={`answer-badge ${answer.is_correct ? 'correct' : 'wrong'}`}>
                    {answer.is_correct ? '✓ Correct' : '✗ Wrong'}
                  </span>
                </div>
                <div className="answer-body">
                  <p><strong>Your Answer:</strong> Option {answer.selected_answer}</p>
                  {!answer.is_correct && (
                    <p className="correct-answer-hint">
                      <strong>Correct Answer:</strong> Check with instructor
                    </p>
                  )}
                </div>
              </div>
            ))
          ) : (
            <p className="no-data">No answer details available</p>
          )}
        </div>

        <div className="action-buttons">
          <button onClick={() => navigate('/candidate/dashboard')} className="back-btn">
            ← Back to Dashboard
          </button>
          <button onClick={() => window.print()} className="print-btn">
            🖨️ Print Result
          </button>
        </div>
      </div>
    </div>
  );
}

export default ResultPage;
