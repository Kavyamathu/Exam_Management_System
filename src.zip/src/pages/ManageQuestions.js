import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './ManageQuestions.css';

function ManageQuestions() {
  const { examId } = useParams();
  const [questions, setQuestions] = useState([]);
  const [exam, setExam] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    exam: examId,
    question_text: '',
    option_a: '',
    option_b: '',
    option_c: '',
    option_d: '',
    correct_answer: 'A',
    marks: '',
    category: '',
    difficulty_level: 'EASY'
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchExam();
    fetchQuestions();
  }, []);

  const fetchExam = async () => {
    try {
      const response = await API.get(`exams/${examId}/`);
      setExam(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchQuestions = async () => {
    try {
      const response = await API.get(`questions/?exam_id=${examId}`);
      setQuestions(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('questions/', formData);
      setShowForm(false);
      fetchQuestions();
      setFormData({
        exam: examId,
        question_text: '',
        option_a: '',
        option_b: '',
        option_c: '',
        option_d: '',
        correct_answer: 'A',
        marks: '',
        category: '',
        difficulty_level: 'EASY'
      });
      alert('Question added successfully!');
    } catch (err) {
      alert('Failed to add question');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this question?')) {
      try {
        await API.delete(`questions/${id}/`);
        fetchQuestions();
      } catch (err) {
        alert('Failed to delete question');
      }
    }
  };

  return (
    <div className="manage-questions">
      <nav className="navbar">
        <h2>Question Bank - {exam?.title}</h2>
        <div>
          <button onClick={() => navigate('/admin/exams')}>Back to Exams</button>
          <button onClick={() => setShowForm(!showForm)}>
            {showForm ? 'Cancel' : 'Add Question'}
          </button>
        </div>
      </nav>

      {showForm && (
        <div className="question-form">
          <h3>Add New Question</h3>
          <form onSubmit={handleSubmit}>
            <textarea
              placeholder="Question Text"
              value={formData.question_text}
              onChange={(e) => setFormData({...formData, question_text: e.target.value})}
              required
              rows="3"
            />
            <input
              placeholder="Option A"
              value={formData.option_a}
              onChange={(e) => setFormData({...formData, option_a: e.target.value})}
              required
            />
            <input
              placeholder="Option B"
              value={formData.option_b}
              onChange={(e) => setFormData({...formData, option_b: e.target.value})}
              required
            />
            <input
              placeholder="Option C"
              value={formData.option_c}
              onChange={(e) => setFormData({...formData, option_c: e.target.value})}
              required
            />
            <input
              placeholder="Option D"
              value={formData.option_d}
              onChange={(e) => setFormData({...formData, option_d: e.target.value})}
              required
            />
            <select
              value={formData.correct_answer}
              onChange={(e) => setFormData({...formData, correct_answer: e.target.value})}
            >
              <option value="A">A is Correct</option>
              <option value="B">B is Correct</option>
              <option value="C">C is Correct</option>
              <option value="D">D is Correct</option>
            </select>
            <input
              type="number"
              placeholder="Marks"
              value={formData.marks}
              onChange={(e) => setFormData({...formData, marks: e.target.value})}
              required
            />
            <input
              placeholder="Category (e.g., Python Basics)"
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
              required
            />
            <select
              value={formData.difficulty_level}
              onChange={(e) => setFormData({...formData, difficulty_level: e.target.value})}
            >
              <option value="EASY">Easy</option>
              <option value="MEDIUM">Medium</option>
              <option value="HARD">Hard</option>
            </select>
            <button type="submit">Add Question</button>
          </form>
        </div>
      )}

      <div className="questions-list">
        <h3>Questions ({questions.length})</h3>
        {questions.map((q, idx) => (
          <div key={q.id} className="question-card">
            <div className="question-header">
              <span className="question-num">Q{idx + 1}</span>
              <span className={`difficulty ${q.difficulty_level.toLowerCase()}`}>
                {q.difficulty_level}
              </span>
              <span className="marks">{q.marks} marks</span>
            </div>
            <p className="question-text">{q.question_text}</p>
            <div className="options">
              <div className={q.correct_answer === 'A' ? 'correct' : ''}>A. {q.option_a}</div>
              <div className={q.correct_answer === 'B' ? 'correct' : ''}>B. {q.option_b}</div>
              <div className={q.correct_answer === 'C' ? 'correct' : ''}>C. {q.option_c}</div>
              <div className={q.correct_answer === 'D' ? 'correct' : ''}>D. {q.option_d}</div>
            </div>
            <div className="question-footer">
              <span>Category: {q.category}</span>
              <button onClick={() => handleDelete(q.id)} className="delete-btn">Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ManageQuestions;
