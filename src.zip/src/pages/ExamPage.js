import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../api/axios';
import './ExamPage.css';

function ExamPage() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [attemptId, setAttemptId] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    startExam();
  }, []);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && exam) {
      handleSubmit();
    }
  }, [timeLeft]);

  const startExam = async () => {
    try {
      console.log('Starting exam with ID:', examId);
      const response = await API.post(`exam/${examId}/start/`);
      console.log('Exam started successfully:', response.data);
      setExam(response.data.exam);
      setAttemptId(response.data.attempt_id);
      setTimeLeft(response.data.exam.duration * 60);
    } catch (err) {
      console.error('Error starting exam:', err);
      const errorMsg = err.response?.data?.error || err.response?.data?.message || 'Failed to start exam. Please try again.';
      alert(errorMsg);
      navigate('/candidate/dashboard');
    }
  };

  const handleAnswer = async (questionId, answer) => {
    setAnswers({ ...answers, [questionId]: answer });
    try {
      await API.post(`attempt/${attemptId}/answer/`, {
        question_id: questionId,
        selected_answer: answer
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async () => {
    if (!window.confirm('Are you sure you want to submit the exam?')) {
      return;
    }
    
    try {
      console.log('Submitting exam, attempt ID:', attemptId);
      const response = await API.post(`attempt/${attemptId}/submit/`);
      console.log('Exam submitted successfully:', response.data);
      alert('Exam submitted successfully! Redirecting to results...');
      navigate(`/result/${attemptId}`);
    } catch (err) {
      console.error('Error submitting exam:', err);
      alert('Failed to submit exam. Please try again.');
    }
  };

  if (!exam) return <div className="loading">Loading exam...</div>;

  const question = exam.questions[currentQuestion];
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="exam-page">
      <div className="exam-header">
        <h2>{exam.title}</h2>
        <div className="timer">
          Time Left: {minutes}:{seconds < 10 ? '0' : ''}{seconds}
        </div>
      </div>

      <div className="exam-content">
        <div className="question-section">
          <h3>Question {currentQuestion + 1} of {exam.questions.length}</h3>
          <p className="question-text">{question.question_text}</p>
          
          <div className="options">
            {['A', 'B', 'C', 'D'].map(option => (
              <div 
                key={option}
                className={`option ${answers[question.id] === option ? 'selected' : ''}`}
                onClick={() => handleAnswer(question.id, option)}
              >
                <input 
                  type="radio" 
                  checked={answers[question.id] === option}
                  readOnly
                />
                <label>{option}. {question[`option_${option.toLowerCase()}`]}</label>
              </div>
            ))}
          </div>
        </div>

        <div className="navigation">
          <button 
            onClick={() => setCurrentQuestion(currentQuestion - 1)}
            disabled={currentQuestion === 0}
          >
            Previous
          </button>
          
          {currentQuestion < exam.questions.length - 1 ? (
            <button onClick={() => setCurrentQuestion(currentQuestion + 1)}>
              Next
            </button>
          ) : (
            <button onClick={handleSubmit} className="submit-btn">
              Submit Exam
            </button>
          )}
        </div>

        <div className="question-palette">
          {exam.questions.map((q, idx) => (
            <div 
              key={q.id}
              className={`palette-item ${answers[q.id] ? 'answered' : ''} ${idx === currentQuestion ? 'current' : ''}`}
              onClick={() => setCurrentQuestion(idx)}
            >
              {idx + 1}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ExamPage;
