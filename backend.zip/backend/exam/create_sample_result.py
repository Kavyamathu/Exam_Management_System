import os
import django
from datetime import datetime, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import User, Exam, Question, ExamAttempt, Answer
from django.utils import timezone

print("=" * 60)
print("CREATING SAMPLE EXAM RESULT")
print("=" * 60)

# Get student1
try:
    student = User.objects.get(username='student1')
    print(f"\n✅ Found student: {student.username}")
except:
    print("\n❌ student1 not found!")
    exit()

# Get Python exam
try:
    exam = Exam.objects.get(title='Python Programming Final Exam')
    print(f"✅ Found exam: {exam.title}")
except:
    print("❌ Python exam not found!")
    exit()

# Check if already attempted
existing = ExamAttempt.objects.filter(candidate=student, exam=exam)
if existing.exists():
    print(f"\n⚠️ Deleting existing attempt...")
    existing.delete()

# Create exam attempt
attempt = ExamAttempt.objects.create(
    candidate=student,
    exam=exam,
    start_time=timezone.now() - timedelta(minutes=25),
    end_time=timezone.now(),
    is_completed=True
)
print(f"\n✅ Created exam attempt (ID: {attempt.id})")

# Get all questions
questions = Question.objects.filter(exam=exam)
print(f"✅ Found {questions.count()} questions")

# Create answers (7 correct, 3 wrong)
correct_count = 0
wrong_count = 0

for i, question in enumerate(questions):
    # First 7 correct, last 3 wrong
    if i < 7:
        selected = question.correct_answer
        is_correct = True
        correct_count += 1
    else:
        # Select wrong answer
        wrong_options = ['A', 'B', 'C', 'D']
        wrong_options.remove(question.correct_answer)
        selected = wrong_options[0]
        is_correct = False
        wrong_count += 1
    
    Answer.objects.create(
        attempt=attempt,
        question=question,
        selected_answer=selected,
        is_correct=is_correct
    )

print(f"✅ Created {correct_count} correct answers")
print(f"✅ Created {wrong_count} wrong answers")

# Calculate score
score = correct_count * 2  # Each question is 2 marks
percentage = (score / exam.total_marks) * 100
is_passed = score >= exam.pass_marks

attempt.score = score
attempt.percentage = percentage
attempt.is_passed = is_passed
attempt.save()

print(f"\n📊 RESULT:")
print(f"   Score: {score}/{exam.total_marks}")
print(f"   Percentage: {percentage}%")
print(f"   Status: {'PASSED ✅' if is_passed else 'FAILED ❌'}")
print(f"   Correct: {correct_count}")
print(f"   Wrong: {wrong_count}")

print("\n" + "=" * 60)
print("✅ SAMPLE RESULT CREATED!")
print("=" * 60)
print(f"\nResult URL: http://localhost:3000/result/{attempt.id}")
print(f"\nOr login as student1 and check 'Completed Exams' section")
print("=" * 60)
