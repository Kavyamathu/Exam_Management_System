from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Exam, Question, ExamAttempt, Answer, Notification

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'is_admin', 'department']
    fieldsets = UserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('age', 'gender', 'phone', 'department', 'organization', 'profile_photo', 'is_admin')}),
    )

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ['title', 'exam_type', 'department', 'exam_date', 'is_active', 'created_by']
    list_filter = ['exam_type', 'department', 'is_active']
    search_fields = ['title', 'department']

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['exam', 'question_text', 'correct_answer', 'marks', 'difficulty_level']
    list_filter = ['difficulty_level', 'category']
    search_fields = ['question_text']

@admin.register(ExamAttempt)
class ExamAttemptAdmin(admin.ModelAdmin):
    list_display = ['candidate', 'exam', 'score', 'percentage', 'is_passed', 'is_completed']
    list_filter = ['is_passed', 'is_completed']
    search_fields = ['candidate__username', 'exam__title']

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['attempt', 'question', 'selected_answer', 'is_correct']
    list_filter = ['is_correct']

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['user', 'notification_type', 'title', 'is_read', 'created_at']
    list_filter = ['notification_type', 'is_read']
    search_fields = ['user__username', 'title']
