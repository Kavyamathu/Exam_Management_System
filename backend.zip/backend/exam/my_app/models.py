from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator

# Custom User Model
class User(AbstractUser):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    
    age = models.IntegerField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, null=True, blank=True)
    phone = models.CharField(max_length=15, null=True, blank=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    organization = models.CharField(max_length=200, null=True, blank=True)
    profile_photo = models.ImageField(upload_to='profiles/', null=True, blank=True)
    is_admin = models.BooleanField(default=False)
    
    def __str__(self):
        return self.username

# Exam Model
class Exam(models.Model):
    EXAM_TYPE_CHOICES = [
        ('MCQ', 'Multiple Choice'),
        ('DESCRIPTIVE', 'Descriptive'),
        ('MIXED', 'Mixed'),
    ]
    
    title = models.CharField(max_length=200)
    exam_type = models.CharField(max_length=20, choices=EXAM_TYPE_CHOICES)
    department = models.CharField(max_length=100)
    total_questions = models.IntegerField()
    duration = models.IntegerField(help_text='Duration in minutes')
    total_marks = models.IntegerField()
    pass_marks = models.IntegerField()
    exam_date = models.DateTimeField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_exams')
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return self.title

# Question Bank Model
class Question(models.Model):
    DIFFICULTY_CHOICES = [
        ('EASY', 'Easy'),
        ('MEDIUM', 'Medium'),
        ('HARD', 'Hard'),
    ]
    
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    option_a = models.CharField(max_length=500)
    option_b = models.CharField(max_length=500)
    option_c = models.CharField(max_length=500)
    option_d = models.CharField(max_length=500)
    correct_answer = models.CharField(max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')])
    marks = models.IntegerField()
    category = models.CharField(max_length=100)
    difficulty_level = models.CharField(max_length=10, choices=DIFFICULTY_CHOICES)
    
    def __str__(self):
        return f"{self.exam.title} - Q{self.id}"

# Exam Attempt Model
class ExamAttempt(models.Model):
    candidate = models.ForeignKey(User, on_delete=models.CASCADE, related_name='exam_attempts')
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='attempts')
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)
    score = models.IntegerField(null=True, blank=True)
    percentage = models.FloatField(null=True, blank=True)
    is_passed = models.BooleanField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)
    
    # Removed unique_together to allow multiple attempts
    
    def __str__(self):
        return f"{self.candidate.username} - {self.exam.title}"

# Answer Model
class Answer(models.Model):
    attempt = models.ForeignKey(ExamAttempt, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    selected_answer = models.CharField(max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')])
    is_correct = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.attempt.candidate.username} - Q{self.question.id}"

# Notification Model
class Notification(models.Model):
    NOTIFICATION_TYPE_CHOICES = [
        ('EXAM_ALERT', 'Exam Alert'),
        ('RESULT_PUBLISHED', 'Result Published'),
        ('UPCOMING_TEST', 'Upcoming Test Reminder'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPE_CHOICES)
    title = models.CharField(max_length=200)
    message = models.TextField()
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, null=True, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.title}"
