from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags

def send_registration_email(user):
    """Send welcome email after registration"""
    subject = 'Welcome to Exam Management System'
    message = f"""
    Dear {user.first_name or user.username},
    
    Welcome to Exam Management System!
    
    Your account has been successfully created.
    
    Login Details:
    Username: {user.username}
    Email: {user.email}
    
    You can now login and take exams.
    
    Best regards,
    Exam Management Team
    """
    
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        print(f"✅ Registration email sent to {user.email}")
        return True
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        return False


def send_exam_scheduled_email(user, exam):
    """Send email when new exam is scheduled"""
    subject = f'New Exam Scheduled: {exam.title}'
    message = f"""
    Dear {user.first_name or user.username},
    
    A new exam has been scheduled for you!
    
    Exam Details:
    Title: {exam.title}
    Department: {exam.department}
    Type: {exam.exam_type}
    Date & Time: {exam.exam_date.strftime('%B %d, %Y at %I:%M %p')}
    Duration: {exam.duration} minutes
    Total Questions: {exam.total_questions}
    Total Marks: {exam.total_marks}
    Pass Marks: {exam.pass_marks}
    
    Please login to the system to take the exam at the scheduled time.
    
    Best regards,
    Exam Management Team
    """
    
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        print(f"✅ Exam scheduled email sent to {user.email}")
        return True
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        return False


def send_exam_reminder_email(user, exam, days_until):
    """Send reminder email before exam"""
    if days_until == 1:
        subject = f'⏰ Exam Tomorrow: {exam.title}'
        message = f"""
        Dear {user.first_name or user.username},
        
        REMINDER: Your exam is scheduled for TOMORROW!
        
        Exam Details:
        Title: {exam.title}
        Date & Time: {exam.exam_date.strftime('%B %d, %Y at %I:%M %p')}
        Duration: {exam.duration} minutes
        Total Marks: {exam.total_marks}
        Pass Marks: {exam.pass_marks}
        
        Please be prepared and login on time.
        
        Good luck!
        
        Best regards,
        Exam Management Team
        """
    else:
        subject = f'📝 Upcoming Exam: {exam.title}'
        message = f"""
        Dear {user.first_name or user.username},
        
        REMINDER: Your exam is scheduled in {days_until} days.
        
        Exam Details:
        Title: {exam.title}
        Date & Time: {exam.exam_date.strftime('%B %d, %Y at %I:%M %p')}
        Duration: {exam.duration} minutes
        Total Marks: {exam.total_marks}
        Pass Marks: {exam.pass_marks}
        
        Start preparing now!
        
        Best regards,
        Exam Management Team
        """
    
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        print(f"✅ Exam reminder email sent to {user.email}")
        return True
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        return False


def send_result_email(user, attempt):
    """Send email when result is published"""
    status = "PASSED ✅" if attempt.is_passed else "FAILED ❌"
    subject = f'Exam Result Published: {attempt.exam.title}'
    message = f"""
    Dear {user.first_name or user.username},
    
    Your exam result has been published!
    
    Exam: {attempt.exam.title}
    Score: {attempt.score}/{attempt.exam.total_marks}
    Percentage: {attempt.percentage:.2f}%
    Status: {status}
    
    {'Congratulations on passing the exam!' if attempt.is_passed else 'Better luck next time!'}
    
    Login to the system to view detailed results.
    
    Best regards,
    Exam Management Team
    """
    
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        print(f"✅ Result email sent to {user.email}")
        return True
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        return False
