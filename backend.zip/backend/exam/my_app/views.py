from rest_framework import viewsets, status, generics
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate, get_user_model
from django.db.models import Avg, Count, Q
from django.utils import timezone
from datetime import timedelta
from .models import Exam, Question, ExamAttempt, Answer, Notification
from .serializers import (
    UserRegistrationSerializer, UserProfileSerializer, ChangePasswordSerializer,
    ExamSerializer, ExamListSerializer, QuestionSerializer,
    ExamAttemptSerializer, AnswerSerializer, NotificationSerializer
)
from .email_utils import (
    send_registration_email, send_exam_scheduled_email,
    send_exam_reminder_email, send_result_email
)

User = get_user_model()

# Authentication Views
@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    serializer = UserRegistrationSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        token, created = Token.objects.get_or_create(user=user)
        
        # Send registration email
        send_registration_email(user)
        
        return Response({
            'token': token.key,
            'user': UserProfileSerializer(user).data,
            'message': 'Registration successful. Check your email for confirmation.'
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    user = authenticate(username=username, password=password)
    if user:
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user': UserProfileSerializer(user).data,
            'message': 'Login successful'
        })
    return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def logout(request):
    request.user.auth_token.delete()
    return Response({'message': 'Logout successful'})

@api_view(['POST'])
@permission_classes([AllowAny])
def forgot_password(request):
    email = request.data.get('email')
    try:
        user = User.objects.get(email=email)
        # Here you would typically send a password reset email
        return Response({'message': 'Password reset link sent to your email'})
    except User.DoesNotExist:
        return Response({'error': 'User with this email does not exist'}, status=status.HTTP_404_NOT_FOUND)

# Profile Views
@api_view(['GET', 'PUT'])
@permission_classes([IsAuthenticated])
def profile(request):
    if request.method == 'GET':
        serializer = UserProfileSerializer(request.user)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = UserProfileSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def change_password(request):
    serializer = ChangePasswordSerializer(data=request.data)
    if serializer.is_valid():
        user = request.user
        if user.check_password(serializer.data.get('old_password')):
            user.set_password(serializer.data.get('new_password'))
            user.save()
            return Response({'message': 'Password changed successfully'})
        return Response({'error': 'Old password is incorrect'}, status=status.HTTP_400_BAD_REQUEST)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# Admin Dashboard
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_dashboard(request):
    if not request.user.is_admin and not request.user.is_staff:
        return Response({'error': 'Admin access required'}, status=status.HTTP_403_FORBIDDEN)
    
    total_candidates = User.objects.filter(is_admin=False).count()
    total_exams = Exam.objects.count()
    active_exams = Exam.objects.filter(is_active=True, exam_date__gte=timezone.now()).count()
    
    completed_attempts = ExamAttempt.objects.filter(is_completed=True)
    total_attempts = completed_attempts.count()
    passed_attempts = completed_attempts.filter(is_passed=True).count()
    pass_percentage = (passed_attempts / total_attempts * 100) if total_attempts > 0 else 0
    
    return Response({
        'total_candidates': total_candidates,
        'total_exams': total_exams,
        'active_exams': active_exams,
        'pass_percentage': round(pass_percentage, 2)
    })

# Exam ViewSet
class ExamViewSet(viewsets.ModelViewSet):
    queryset = Exam.objects.all()
    permission_classes = [IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'list':
            return ExamListSerializer
        return ExamSerializer
    
    def perform_create(self, serializer):
        exam = serializer.save(created_by=self.request.user)
        
        # Create notifications for all candidates
        candidates = User.objects.filter(is_admin=False, is_staff=False)
        for candidate in candidates:
            Notification.objects.create(
                user=candidate,
                exam=exam,
                notification_type='EXAM_ALERT',
                title=f'📝 New Exam Scheduled: {exam.title}',
                message=f'A new exam "{exam.title}" has been scheduled for {exam.exam_date.strftime("%B %d, %Y at %I:%M %p")}. Department: {exam.department}. Duration: {exam.duration} minutes. Total Marks: {exam.total_marks}. Pass Marks: {exam.pass_marks}.',
                is_read=False
            )
            
            # Send email notification
            send_exam_scheduled_email(candidate, exam)
        
        return exam
    
    @action(detail=False, methods=['get'])
    def upcoming(self, request):
        upcoming_exams = Exam.objects.filter(
            exam_date__gte=timezone.now(),
            is_active=True
        ).order_by('exam_date')
        serializer = ExamListSerializer(upcoming_exams, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def active(self, request):
        active_exams = Exam.objects.filter(is_active=True)
        serializer = ExamListSerializer(active_exams, many=True)
        return Response(serializer.data)

# Question ViewSet
class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = Question.objects.all()
        exam_id = self.request.query_params.get('exam_id', None)
        if exam_id:
            queryset = queryset.filter(exam_id=exam_id)
        return queryset

# Candidate Dashboard
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def candidate_dashboard(request):
    user = request.user
    
    # Upcoming exams - SHOW ALL ACTIVE EXAMS (don't exclude attempted ones)
    # This way exams always show, even after taking them
    upcoming_exams = Exam.objects.filter(
        is_active=True
    ).order_by('exam_date')[:10]
    
    # Completed exams
    completed_attempts = ExamAttempt.objects.filter(
        candidate=user,
        is_completed=True
    ).order_by('-end_time')[:5]
    
    # Recent notifications
    notifications = Notification.objects.filter(user=user, is_read=False)[:5]
    
    return Response({
        'upcoming_exams': ExamListSerializer(upcoming_exams, many=True).data,
        'completed_exams': ExamAttemptSerializer(completed_attempts, many=True).data,
        'notifications': NotificationSerializer(notifications, many=True).data
    })

# Exam Attempt Views
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def start_exam(request, exam_id):
    try:
        exam = Exam.objects.get(id=exam_id)
        
        # Check if already attempted - if yes, DELETE old attempt to allow retake
        existing_attempts = ExamAttempt.objects.filter(candidate=request.user, exam=exam)
        if existing_attempts.exists():
            # Delete old attempts and their answers
            for old_attempt in existing_attempts:
                Answer.objects.filter(attempt=old_attempt).delete()
                old_attempt.delete()
            print(f"✅ Deleted old attempts for {request.user.username} - {exam.title}")
        
        # Create new attempt
        attempt = ExamAttempt.objects.create(
            candidate=request.user,
            exam=exam
        )
        
        return Response({
            'attempt_id': attempt.id,
            'exam': ExamSerializer(exam).data,
            'message': 'Exam started successfully'
        })
    except Exam.DoesNotExist:
        return Response({'error': 'Exam not found'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def submit_answer(request, attempt_id):
    try:
        attempt = ExamAttempt.objects.get(id=attempt_id, candidate=request.user)
        question_id = request.data.get('question_id')
        selected_answer = request.data.get('selected_answer')
        
        question = Question.objects.get(id=question_id, exam=attempt.exam)
        is_correct = question.correct_answer == selected_answer
        
        answer, created = Answer.objects.update_or_create(
            attempt=attempt,
            question=question,
            defaults={
                'selected_answer': selected_answer,
                'is_correct': is_correct
            }
        )
        
        return Response({
            'message': 'Answer saved successfully',
            'is_correct': is_correct
        })
    except (ExamAttempt.DoesNotExist, Question.DoesNotExist):
        return Response({'error': 'Invalid attempt or question'}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def submit_exam(request, attempt_id):
    try:
        attempt = ExamAttempt.objects.get(id=attempt_id, candidate=request.user)
        
        # Calculate score
        correct_answers = Answer.objects.filter(attempt=attempt, is_correct=True)
        score = sum([answer.question.marks for answer in correct_answers])
        percentage = (score / attempt.exam.total_marks) * 100
        is_passed = score >= attempt.exam.pass_marks
        
        attempt.end_time = timezone.now()
        attempt.score = score
        attempt.percentage = percentage
        attempt.is_passed = is_passed
        attempt.is_completed = True
        attempt.save()
        
        # Create notification
        Notification.objects.create(
            user=request.user,
            notification_type='RESULT_PUBLISHED',
            title='Exam Result Published',
            message=f'Your result for {attempt.exam.title} has been published',
            exam=attempt.exam
        )
        
        # Send result email
        send_result_email(request.user, attempt)
        
        return Response({
            'message': 'Exam submitted successfully',
            'result': ExamAttemptSerializer(attempt).data
        })
    except ExamAttempt.DoesNotExist:
        return Response({'error': 'Attempt not found'}, status=status.HTTP_404_NOT_FOUND)

# Result View
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def exam_result(request, attempt_id):
    try:
        attempt = ExamAttempt.objects.get(id=attempt_id, candidate=request.user)
        answers = Answer.objects.filter(attempt=attempt)
        
        correct_count = answers.filter(is_correct=True).count()
        wrong_count = answers.filter(is_correct=False).count()
        
        return Response({
            'attempt': ExamAttemptSerializer(attempt).data,
            'correct_answers': correct_count,
            'wrong_answers': wrong_count,
            'total_questions': answers.count(),
            'answers': AnswerSerializer(answers, many=True).data
        })
    except ExamAttempt.DoesNotExist:
        return Response({'error': 'Result not found'}, status=status.HTTP_404_NOT_FOUND)

# Performance Analytics (Admin)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def performance_analytics(request):
    if not request.user.is_admin and not request.user.is_staff:
        return Response({'error': 'Admin access required'}, status=status.HTTP_403_FORBIDDEN)
    
    exam_id = request.query_params.get('exam_id', None)
    
    if exam_id:
        attempts = ExamAttempt.objects.filter(exam_id=exam_id, is_completed=True)
    else:
        attempts = ExamAttempt.objects.filter(is_completed=True)
    
    # Top scorers
    top_scorers = attempts.order_by('-score')[:10].values(
        'candidate__username', 'candidate__email', 'score', 'percentage', 'exam__title'
    )
    
    # Average score
    avg_score = attempts.aggregate(Avg('score'))['score__avg'] or 0
    
    # Pass/Fail ratio
    total = attempts.count()
    passed = attempts.filter(is_passed=True).count()
    failed = total - passed
    
    return Response({
        'top_scorers': list(top_scorers),
        'average_score': round(avg_score, 2),
        'pass_fail_ratio': {
            'passed': passed,
            'failed': failed,
            'total': total
        }
    })

# Notification ViewSet
class NotificationViewSet(viewsets.ModelViewSet):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)
    
    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        notification.is_read = True
        notification.save()
        return Response({'message': 'Notification marked as read'})
    
    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
        return Response({'message': 'All notifications marked as read'})
