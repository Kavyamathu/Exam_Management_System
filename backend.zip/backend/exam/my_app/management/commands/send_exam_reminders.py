from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from my_app.models import Exam, Notification, User
from my_app.email_utils import send_exam_reminder_email

class Command(BaseCommand):
    help = 'Send exam reminder notifications to candidates'

    def handle(self, *args, **kwargs):
        now = timezone.now()
        
        # Get all active exams
        upcoming_exams = Exam.objects.filter(
            is_active=True,
            exam_date__gte=now
        )
        
        # Get all candidates (non-admin users)
        candidates = User.objects.filter(is_admin=False, is_staff=False)
        
        notifications_created = 0
        
        for exam in upcoming_exams:
            days_until = (exam.exam_date - now).days
            hours_until = (exam.exam_date - now).total_seconds() / 3600
            
            # Send notification 1 day before
            if 20 <= hours_until <= 28:  # Between 20-28 hours (roughly 1 day)
                for candidate in candidates:
                    # Check if notification already exists
                    exists = Notification.objects.filter(
                        user=candidate,
                        exam=exam,
                        notification_type='UPCOMING_TEST',
                        created_at__gte=now - timedelta(hours=24)
                    ).exists()
                    
                    if not exists:
                        Notification.objects.create(
                            user=candidate,
                            exam=exam,
                            notification_type='UPCOMING_TEST',
                            title=f'⏰ Exam Tomorrow: {exam.title}',
                            message=f'Reminder: Your exam "{exam.title}" is scheduled for tomorrow at {exam.exam_date.strftime("%I:%M %p")}. Duration: {exam.duration} minutes. Total Marks: {exam.total_marks}. Please be prepared!',
                            is_read=False
                        )
                        # Send email
                        send_exam_reminder_email(candidate, exam, 1)
                        notifications_created += 1
                        self.stdout.write(f'Created reminder for {candidate.username} - {exam.title}')
            
            # Send notification 1 week before
            elif 6 <= days_until <= 8:
                for candidate in candidates:
                    exists = Notification.objects.filter(
                        user=candidate,
                        exam=exam,
                        notification_type='EXAM_ALERT',
                        created_at__gte=now - timedelta(days=7)
                    ).exists()
                    
                    if not exists:
                        Notification.objects.create(
                            user=candidate,
                            exam=exam,
                            notification_type='EXAM_ALERT',
                            title=f'📝 Upcoming Exam: {exam.title}',
                            message=f'Your exam "{exam.title}" is scheduled for {exam.exam_date.strftime("%B %d, %Y at %I:%M %p")}. Start preparing now! Total Questions: {exam.total_questions}, Pass Marks: {exam.pass_marks}',
                            is_read=False
                        )
                        # Send email
                        send_exam_reminder_email(candidate, exam, 7)
                        notifications_created += 1
                        self.stdout.write(f'Created week reminder for {candidate.username} - {exam.title}')
        
        self.stdout.write(self.style.SUCCESS(f'✅ Created {notifications_created} notifications'))
