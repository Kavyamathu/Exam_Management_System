from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'exams', views.ExamViewSet, basename='exam')
router.register(r'questions', views.QuestionViewSet, basename='question')
router.register(r'notifications', views.NotificationViewSet, basename='notification')

urlpatterns = [
    # Authentication URLs
    path('auth/register/', views.register, name='register'),
    path('auth/login/', views.login, name='login'),
    path('auth/logout/', views.logout, name='logout'),
    path('auth/forgot-password/', views.forgot_password, name='forgot-password'),
    
    # Profile URLs
    path('profile/', views.profile, name='profile'),
    path('profile/change-password/', views.change_password, name='change-password'),
    
    # Dashboard URLs
    path('admin/dashboard/', views.admin_dashboard, name='admin-dashboard'),
    path('candidate/dashboard/', views.candidate_dashboard, name='candidate-dashboard'),
    
    # Exam Attempt URLs
    path('exam/<int:exam_id>/start/', views.start_exam, name='start-exam'),
    path('attempt/<int:attempt_id>/answer/', views.submit_answer, name='submit-answer'),
    path('attempt/<int:attempt_id>/submit/', views.submit_exam, name='submit-exam'),
    path('attempt/<int:attempt_id>/result/', views.exam_result, name='exam-result'),
    
    # Analytics URLs
    path('admin/analytics/', views.performance_analytics, name='performance-analytics'),
    
    # Router URLs
    path('', include(router.urls)),
]
