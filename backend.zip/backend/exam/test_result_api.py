import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import ExamAttempt, Answer, User
from rest_framework.authtoken.models import Token

print("=" * 60)
print("TESTING RESULT API")
print("=" * 60)

# Check attempt exists
try:
    attempt = ExamAttempt.objects.get(id=3)
    print(f"\n✅ Attempt found:")
    print(f"   ID: {attempt.id}")
    print(f"   Candidate: {attempt.candidate.username}")
    print(f"   Exam: {attempt.exam.title}")
    print(f"   Score: {attempt.score}/{attempt.exam.total_marks}")
    print(f"   Percentage: {attempt.percentage}%")
    print(f"   Passed: {attempt.is_passed}")
    print(f"   Completed: {attempt.is_completed}")
except ExamAttempt.DoesNotExist:
    print("\n❌ Attempt ID 3 not found!")
    exit()

# Check answers
answers = Answer.objects.filter(attempt=attempt)
print(f"\n✅ Answers found: {answers.count()}")
correct = answers.filter(is_correct=True).count()
wrong = answers.filter(is_correct=False).count()
print(f"   Correct: {correct}")
print(f"   Wrong: {wrong}")

# Check student1 token
try:
    student = User.objects.get(username='student1')
    token = Token.objects.get(user=student)
    print(f"\n✅ Student1 token: {token.key}")
except:
    print("\n❌ Token not found for student1")

# Check if attempt belongs to student1
if attempt.candidate.username == 'student1':
    print(f"\n✅ Attempt belongs to student1")
else:
    print(f"\n⚠️ Attempt belongs to {attempt.candidate.username}, not student1")

print("\n" + "=" * 60)
print("API ENDPOINT:")
print("=" * 60)
print(f"\nGET http://127.0.0.1:8000/api/attempt/3/result/")
print(f"Authorization: Token {token.key}")
print("\n" + "=" * 60)
