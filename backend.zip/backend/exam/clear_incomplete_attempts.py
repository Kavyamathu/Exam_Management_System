import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import ExamAttempt

print("=" * 60)
print("CLEARING INCOMPLETE ATTEMPTS")
print("=" * 60)

# Find incomplete attempts
incomplete = ExamAttempt.objects.filter(is_completed=False)
print(f"\nFound {incomplete.count()} incomplete attempts")

if incomplete.count() > 0:
    for attempt in incomplete:
        print(f"\nDeleting:")
        print(f"  User: {attempt.candidate.username}")
        print(f"  Exam: {attempt.exam.title}")
        print(f"  Started: {attempt.start_time}")
        attempt.delete()
        print("  ✅ Deleted")

print("\n" + "=" * 60)
print("✅ ALL INCOMPLETE ATTEMPTS CLEARED!")
print("=" * 60)
print("\nNow all users can start exams fresh!")
