import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import ExamAttempt, User, Exam

print("=" * 60)
print("EXAM ATTEMPTS CHECK")
print("=" * 60)

# Check all attempts
attempts = ExamAttempt.objects.all()
print(f"\nTotal Exam Attempts: {attempts.count()}")

if attempts.count() > 0:
    print("\nExisting Attempts:")
    for attempt in attempts:
        print(f"\n  Candidate: {attempt.candidate.username}")
        print(f"  Exam: {attempt.exam.title}")
        print(f"  Started: {attempt.start_time}")
        print(f"  Completed: {attempt.is_completed}")
        print(f"  Score: {attempt.score}")
else:
    print("\n✅ No attempts yet - All exams available for testing!")

# Check students
print("\n" + "=" * 60)
print("STUDENTS STATUS")
print("=" * 60)

students = User.objects.filter(is_admin=False, is_staff=False)
for student in students:
    print(f"\n{student.username}:")
    student_attempts = ExamAttempt.objects.filter(candidate=student)
    if student_attempts.count() == 0:
        print("  ✅ No attempts - Can take all exams")
    else:
        print(f"  Attempted {student_attempts.count()} exams:")
        for attempt in student_attempts:
            print(f"    - {attempt.exam.title} (Completed: {attempt.is_completed})")

# Check exams
print("\n" + "=" * 60)
print("EXAMS STATUS")
print("=" * 60)

exams = Exam.objects.all()
for exam in exams:
    print(f"\n{exam.title}:")
    print(f"  Date: {exam.exam_date}")
    print(f"  Active: {exam.is_active}")
    print(f"  Questions: {exam.total_questions}")
    exam_attempts = ExamAttempt.objects.filter(exam=exam)
    print(f"  Attempts: {exam_attempts.count()}")

print("\n" + "=" * 60)
