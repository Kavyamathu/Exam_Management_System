import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import User
from rest_framework.authtoken.models import Token

print("=" * 60)
print("CREATING TOKENS FOR ALL USERS")
print("=" * 60)

users = User.objects.all()

for user in users:
    token, created = Token.objects.get_or_create(user=user)
    if created:
        print(f"\n✅ Created token for {user.username}")
    else:
        print(f"\n✅ Token exists for {user.username}")
    print(f"   Token: {token.key}")

print("\n" + "=" * 60)
print("✅ ALL TOKENS READY!")
print("=" * 60)
