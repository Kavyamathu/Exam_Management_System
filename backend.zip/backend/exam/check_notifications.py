import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import Notification, User, Exam

print("=" * 60)
print("NOTIFICATION SYSTEM STATUS")
print("=" * 60)

# Count notifications
total_notifs = Notification.objects.count()
print(f"\n✅ Total Notifications: {total_notifs}")

# Count by type
exam_alerts = Notification.objects.filter(notification_type='EXAM_ALERT').count()
upcoming_tests = Notification.objects.filter(notification_type='UPCOMING_TEST').count()
results = Notification.objects.filter(notification_type='RESULT_PUBLISHED').count()

print(f"\nNotifications by Type:")
print(f"  📝 EXAM_ALERT: {exam_alerts}")
print(f"  ⏰ UPCOMING_TEST: {upcoming_tests}")
print(f"  📊 RESULT_PUBLISHED: {results}")

# Count by user
print(f"\nNotifications by User:")
candidates = User.objects.filter(is_admin=False, is_staff=False)
for candidate in candidates:
    count = Notification.objects.filter(user=candidate).count()
    unread = Notification.objects.filter(user=candidate, is_read=False).count()
    print(f"  {candidate.username}: {count} total ({unread} unread)")

# Show sample notifications
print(f"\n📋 Sample Notifications:")
for notif in Notification.objects.all()[:5]:
    print(f"\n  User: {notif.user.username}")
    print(f"  Type: {notif.notification_type}")
    print(f"  Title: {notif.title}")
    print(f"  Exam: {notif.exam.title if notif.exam else 'N/A'}")
    print(f"  Read: {'Yes' if notif.is_read else 'No'}")

# Show exams
print(f"\n📚 Exams Created:")
exams = Exam.objects.all()
for exam in exams:
    print(f"\n  {exam.title}")
    print(f"    Date: {exam.exam_date.strftime('%B %d, %Y at %I:%M %p')}")
    print(f"    Questions: {exam.total_questions}")
    print(f"    Marks: {exam.total_marks}")
    print(f"    Active: {'Yes' if exam.is_active else 'No'}")

print("\n" + "=" * 60)
print("✅ SYSTEM IS READY!")
print("=" * 60)
