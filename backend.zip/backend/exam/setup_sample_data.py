import os
import django
from datetime import datetime, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from django.contrib.auth import get_user_model
from my_app.models import Exam, Question, Notification
from django.utils import timezone

User = get_user_model()

def create_sample_data():
    print("Creating sample data...")
    
    # Create sample candidates
    candidates = []
    candidate_data = [
        {'username': 'student1', 'email': 'student1@example.com', 'first_name': 'Raj', 'last_name': 'Kumar', 'department': 'Computer Science'},
        {'username': 'student2', 'email': 'student2@example.com', 'first_name': 'Priya', 'last_name': 'Sharma', 'department': 'Information Technology'},
        {'username': 'student3', 'email': 'student3@example.com', 'first_name': 'Arun', 'last_name': 'Patel', 'department': 'Computer Science'},
    ]
    
    for data in candidate_data:
        user, created = User.objects.get_or_create(
            username=data['username'],
            defaults={
                'email': data['email'],
                'first_name': data['first_name'],
                'last_name': data['last_name'],
                'department': data['department'],
                'age': 22,
                'gender': 'M',
                'phone': '9876543210',
                'organization': 'ABC University'
            }
        )
        if created:
            user.set_password('password123')
            user.save()
            print(f"Created candidate: {data['username']}")
        candidates.append(user)
    
    # Get admin user
    admin = User.objects.get(username='admin')
    
    # Create exams with different dates
    exams_data = [
        {
            'title': 'Python Programming Final Exam',
            'exam_type': 'MCQ',
            'department': 'Computer Science',
            'total_questions': 10,
            'duration': 30,
            'total_marks': 20,
            'pass_marks': 10,
            'exam_date': timezone.now() + timedelta(days=1),  # Tomorrow
            'is_active': True
        },
        {
            'title': 'Java Fundamentals Test',
            'exam_type': 'MCQ',
            'department': 'Computer Science',
            'total_questions': 8,
            'duration': 25,
            'total_marks': 16,
            'pass_marks': 8,
            'exam_date': timezone.now() + timedelta(days=3),  # 3 days later
            'is_active': True
        },
        {
            'title': 'Database Management Systems',
            'exam_type': 'MCQ',
            'department': 'Information Technology',
            'total_questions': 12,
            'duration': 40,
            'total_marks': 24,
            'pass_marks': 12,
            'exam_date': timezone.now() + timedelta(days=7),  # Next week
            'is_active': True
        },
        {
            'title': 'Web Development Basics',
            'exam_type': 'MIXED',
            'department': 'Computer Science',
            'total_questions': 15,
            'duration': 45,
            'total_marks': 30,
            'pass_marks': 15,
            'exam_date': timezone.now() + timedelta(days=14),  # 2 weeks later
            'is_active': True
        }
    ]
    
    created_exams = []
    for exam_data in exams_data:
        exam, created = Exam.objects.get_or_create(
            title=exam_data['title'],
            defaults={**exam_data, 'created_by': admin}
        )
        if created:
            print(f"Created exam: {exam_data['title']}")
        created_exams.append(exam)
    
    # Add questions to first exam (Python)
    python_exam = created_exams[0]
    python_questions = [
        {
            'question_text': 'What is the output of print(2 ** 3)?',
            'option_a': '6',
            'option_b': '8',
            'option_c': '9',
            'option_d': '5',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Basics',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'Which keyword is used to define a function in Python?',
            'option_a': 'function',
            'option_b': 'def',
            'option_c': 'func',
            'option_d': 'define',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Functions',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'What is the correct file extension for Python files?',
            'option_a': '.python',
            'option_b': '.py',
            'option_c': '.pt',
            'option_d': '.pyt',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Basics',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'Which of the following is a mutable data type in Python?',
            'option_a': 'tuple',
            'option_b': 'list',
            'option_c': 'string',
            'option_d': 'int',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Data Types',
            'difficulty_level': 'MEDIUM'
        },
        {
            'question_text': 'What does the len() function do?',
            'option_a': 'Returns the length of an object',
            'option_b': 'Returns the type of an object',
            'option_c': 'Returns the value of an object',
            'option_d': 'Returns the name of an object',
            'correct_answer': 'A',
            'marks': 2,
            'category': 'Python Built-in Functions',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'Which operator is used for floor division in Python?',
            'option_a': '/',
            'option_b': '//',
            'option_c': '%',
            'option_d': '**',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Operators',
            'difficulty_level': 'MEDIUM'
        },
        {
            'question_text': 'What is the output of print(type([]))?',
            'option_a': '<class \'list\'>',
            'option_b': '<class \'array\'>',
            'option_c': '<class \'tuple\'>',
            'option_d': '<class \'dict\'>',
            'correct_answer': 'A',
            'marks': 2,
            'category': 'Python Data Types',
            'difficulty_level': 'MEDIUM'
        },
        {
            'question_text': 'Which method is used to add an element to a list?',
            'option_a': 'add()',
            'option_b': 'append()',
            'option_c': 'insert()',
            'option_d': 'push()',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Lists',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'What is the correct way to create a dictionary in Python?',
            'option_a': 'dict = []',
            'option_b': 'dict = ()',
            'option_c': 'dict = {}',
            'option_d': 'dict = <>',
            'correct_answer': 'C',
            'marks': 2,
            'category': 'Python Dictionaries',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'Which keyword is used to handle exceptions in Python?',
            'option_a': 'catch',
            'option_b': 'except',
            'option_c': 'handle',
            'option_d': 'error',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Python Exception Handling',
            'difficulty_level': 'MEDIUM'
        }
    ]
    
    for q_data in python_questions:
        question, created = Question.objects.get_or_create(
            exam=python_exam,
            question_text=q_data['question_text'],
            defaults=q_data
        )
        if created:
            print(f"Added question: {q_data['question_text'][:50]}...")
    
    # Add questions to Java exam
    java_exam = created_exams[1]
    java_questions = [
        {
            'question_text': 'What is the size of int in Java?',
            'option_a': '2 bytes',
            'option_b': '4 bytes',
            'option_c': '8 bytes',
            'option_d': '16 bytes',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Java Basics',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'Which keyword is used to inherit a class in Java?',
            'option_a': 'inherits',
            'option_b': 'extends',
            'option_c': 'implements',
            'option_d': 'super',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Java OOP',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'What is the default value of boolean in Java?',
            'option_a': 'true',
            'option_b': 'false',
            'option_c': '0',
            'option_d': 'null',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Java Data Types',
            'difficulty_level': 'EASY'
        },
        {
            'question_text': 'Which method is the entry point of a Java program?',
            'option_a': 'start()',
            'option_b': 'main()',
            'option_c': 'run()',
            'option_d': 'execute()',
            'correct_answer': 'B',
            'marks': 2,
            'category': 'Java Basics',
            'difficulty_level': 'EASY'
        }
    ]
    
    for q_data in java_questions:
        question, created = Question.objects.get_or_create(
            exam=java_exam,
            question_text=q_data['question_text'],
            defaults=q_data
        )
        if created:
            print(f"Added question: {q_data['question_text'][:50]}...")
    
    # Create notifications for all candidates
    for candidate in candidates:
        for exam in created_exams:
            days_until = (exam.exam_date - timezone.now()).days
            
            if days_until == 1:
                message = f"Reminder: Your exam '{exam.title}' is scheduled for tomorrow at {exam.exam_date.strftime('%I:%M %p')}. Please be prepared!"
                notif_type = 'UPCOMING_TEST'
            elif days_until <= 7:
                message = f"Upcoming exam '{exam.title}' is scheduled on {exam.exam_date.strftime('%B %d, %Y at %I:%M %p')}. Start preparing now!"
                notif_type = 'EXAM_ALERT'
            else:
                message = f"New exam '{exam.title}' has been scheduled for {exam.exam_date.strftime('%B %d, %Y at %I:%M %p')}."
                notif_type = 'EXAM_ALERT'
            
            notification, created = Notification.objects.get_or_create(
                user=candidate,
                exam=exam,
                notification_type=notif_type,
                defaults={
                    'title': f"Exam Notification - {exam.title}",
                    'message': message,
                    'is_read': False
                }
            )
            if created:
                print(f"Created notification for {candidate.username} - {exam.title}")
    
    print("\n✅ Sample data created successfully!")
    print(f"\n📊 Summary:")
    print(f"- Candidates: {len(candidates)}")
    print(f"- Exams: {len(created_exams)}")
    print(f"- Questions (Python): {len(python_questions)}")
    print(f"- Questions (Java): {len(java_questions)}")
    print(f"- Notifications: {Notification.objects.count()}")
    
    print(f"\n🔐 Test Credentials:")
    print(f"Admin: username=admin, password=admin123")
    for data in candidate_data:
        print(f"Candidate: username={data['username']}, password=password123")

if __name__ == '__main__':
    create_sample_data()
