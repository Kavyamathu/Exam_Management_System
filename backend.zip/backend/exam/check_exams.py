import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exam.settings')
django.setup()

from my_app.models import Exam, ExamAttempt, User

print("=" * 60)
print("CHECKING EXAMS & ATTEMPTS")
print("=" * 60)

# Check all exams
exams = Exam.objects.all()
print(f"\nTotal Exams: {exams.count()}")
for exam in exams:
    print(f"\n{exam.id}. {exam.title}")
    print(f"   Active: {exam.is_active}")
    print(f"   Questions: {exam.total_questions}")

# Check attempts
attempts = ExamAttempt.objects.all()
print(f"\n\nTotal Attempts: {attempts.count()}")
for attempt in attempts:
    print(f"\n- User: {attempt.candidate.username}")
    print(f"  Exam: {attempt.exam.title}")
    print(f"  Completed: {attempt.is_completed}")

# Check for specific user
try:
    user = User.objects.get(username='student1')
    user_attempts = ExamAttempt.objects.filter(candidate=user)
    print(f"\n\nStudent1 Attempts: {user_attempts.count()}")
    for attempt in user_attempts:
        print(f"- {attempt.exam.title} (Completed: {attempt.is_completed})")
except:
    print("\nStudent1 not found")

print("\n" + "=" * 60)
